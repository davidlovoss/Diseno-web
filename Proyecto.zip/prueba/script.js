const categorias = [
    [
               "RESTAURANTES",
               "Pollo Campestre: 15% de descuento en menú regular.",
               "Federal, Alta Cocina Mexicana: 10% de descuento en consumo. Cumpleañero come gratis con ciertas condiciones.",
               "Al Horno: 10% de descuento de lunes a miércoles en consumo.",
               "FONTANA, GASTROBAR: 10% de descuento en almuerzos de 11:00 a.m. a 3:00 p.m.",
               "Don Beto: 10% de descuento en desayunos de 7:00 a.m. a 11:00 a.m.",
               "Frela, Fresh & Cool: 15% de descuento en consumo total en menú regular."
           ],
           [
               "Pastelería Lorena: 10% de descuento en pasteles de línea.",
               "Benditos Churros: 10% de descuento en productos.",
               "KIKI Café: Promociones en frappes, flanes, waffles, sándwiches y bebidas calientes.",
               "Tartaleta, Bistro & Café: 10% de descuento en pasteles de línea."
           ],
           [
               "SMART MODA: 25% de descuento en ropa con pago en efectivo.",
               "Celebrity Fashion Store: Descuentos en prendas de vestir, lencería y accesorios.",
               "Flores Boutique: 15% de descuento en ropa y 25% en accesorios."
           ],
           [
               "Legend's Barber Shop: 15% de descuento en corte de cabello y limpieza facial.",
               "Salón Sofia Villatoro: Descuentos en servicios de salón lunes y martes.",
               "Serrano Hair Design: 15% de descuento en tratamientos químicos y paquete de peinado/maquillaje."
           ],
           [
               "Hospital de Especialidades Nuestra Señora de la Paz: Descuentos en laboratorio clínico, Rayos X y ultrasonografía.",
               "Hospital San Gabriel: Consulta médica y descuentos en exámenes médicos.",
               "Hospital San Francisco: 10% de descuento en laboratorio clínico y servicios hospitalarios.",
               "Analiza, Laboratorios Clínicos: 30% de descuento en pruebas generales.",
               "Laboratorio Santín Díaz: 15% de descuento en todos los análisis.",
               "Novadent: 20% de descuento en limpiezas dentales y 50% en ortodoncia.",
               "Óptica Jerusalén: Examen visual sin costo y descuentos en compras de anteojos.",
               "Óptica Oftalmológica: Descuento del 15% en servicios ópticos."
           ]
   [
       "SALUD",
       "Analiza, Laboratorios Clínicos: 30% de descuento en pruebas generales.",
       "Novadent: 20% de descuento en limpiezas dentales y 50% en ortodoncia.",
       "Óptica Jerusalén: Examen visual sin costo y descuentos en compras de anteojos.",
       "Óptica Oftalmológica: Descuento del 15% en servicios ópticos.",
       "Ópticas CV+: Exámenes visuales gratuitos y descuentos en lentes.",
       "Equimed: Descuentos en equipos médicos y capacitaciones.",
       "Electrolab Medic: Descuentos en insumos médicos y uniformes."
   ],
   [
       "CUIDADO PERSONAL",
       "Life Fitness Gym: Precio especial de membresía.",
       "Nautiluss Gym: Membresía a precio reducido.",
       "Warriors Gym: 10% de descuento en mensualidad y servicios de entrenamiento."
   ],
   [
       "LIBRERÍAS",
       "Distribuidora Papelera DM: Descuentos en productos escolares y tecnología.",
       "Librería Medalla Milagrosa: 10% de descuento en productos a precio regular."
   ],
   [
       "AUTOMOTRIZ",
       "Platinum Multiservice: Descuentos en lavado de vehículos, accesorios y calibración.",
       "Elite Renta Car: Descuentos progresivos en renta de vehículos."
   ],
   [
       "HOTELES",
       "Hotel y Restaurante Marbella: 10% de descuento en habitaciones y pasadía gratis."
   ]
       [
       "Otros",
       "PinPon Beneficios para colaboradores y estudiantes de la Universidad de Oriente UNIVO: 10% de descuento en compras de todo tipo de productos. 10% de descuento en contratación de eventos, Restricciones: Válido únicamente presentando su carnet UNIVO vigente"
   ]
];

function mostrarCategoria(index) {
   document.getElementById("listaDetalles").innerHTML = categorias[index].map(item => `<p>${item}</p>`).join("");
   document.getElementById("modal").style.display = "flex";
}

function cerrarDetalles() {
   document.getElementById("modal").style.display = "none";
}
